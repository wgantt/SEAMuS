# Experiments on the Impact of Extraction Quality

This directory contains files used in the experiments on the impact of extraction quality. Edits were created separately for the report texts (`report_edits/`) and source texts (`source_edits/`). Within each of these directories, there are subdirectories for each split. Note that the `dev` split is empty for both `report_edits/` and `source_edits/`, as we did not use the dev split in these experiments. Here is a guide to the naming conventions of the files:

- Files named `{report,source}_edits_{0.10,0.20,0.30,0.40,0.50}.json` contain the edits to be made for each example. These files were constructed by running `scripts/corruption/generate_edit_files.sh`.
- Files ending in `prompts.jsonl` contain the prompts used to actually *make* these edits. Each of these files were constructed by running `scripts/corruption/generate_edit_prompts.sh`.
- Files ending in `response.jsonl` contain the LLM responses containing the implemented edits.
- Files ending in `corrupted.json` contain the post-processed LLM responses: versions of the SEAMuS data that have been modified based on the edits made by the LLM. These files were constructed by running `scripts/corruption/postprocess_all_corrupted_annotations.sh`. To reproduce our experiments on the impact of extraction quality, you should use these files as input data.
