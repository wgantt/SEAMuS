# Report Summary Annotation

The primary aim of this annotation project is to write short summaries of specific events. Each example to be annotated will feature a short `report` text, along with some information about an event described in the report. This event information is specified as a set of annotations based on (a subset of) the [FrameNet](https://framenet.icsi.berkeley.edu/frameIndex) ontology. As part of writing these summaries, you may also have to correct some of these annotations if they contain errors. The annotation correction and the summary writing will thus be carried out in tandem.

For this project, you will not need to understand FrameNet in great detail before you begin. In a nutshell, FrameNet is an annotation scheme for semantic role labeling (SRL) that covers a wide range of different event and role types. The event types are called *frames* and they vary in their level of specificity &mdash; e.g. from types as specific as `Bail_decision` to types as general as `Activity`. Each frame is associated with a distinct set of role types (or "frame elements") that characterize the way in which a participant (a person, thing, place, etc.) can be involved in that kind of event. For instance, the `Bail_decision` has the frame elements `Accused` (for the person about whom a bail decision is being made) and `Judge` (for the person making the bail decision), among other frame elements.

The annotations you will be using to write your summaries feature lots of different frames. To help you understand their meaning, the files you will be annotating include definitions of both the frames and of their roles as given in the [FrameNet Documentation](https://framenet.icsi.berkeley.edu/frameIndex). Even with these definitions provided, you may occasionally find it helpful to look up a particular frame in the documentation in order to see other examples of its use; this is encouraged. Next, we share some more details about the data that you will be annotating.

## Data for Annotation

Each example to be annotated will be provided as its own JSON dictionary in a JSON file. Apart from the `report` text, each example will include the following fields:

- `instance_id`: A unique identifier for this example
- `example_number`: This example's number within the data split it belongs to (train, dev, or test)
- `trigger`: The span of text in the `report` that most clearly evokes the event to be summarized. The `trigger` JSON dictionary includes the following fields:
  - `text`: The trigger span from the `report` text
  - `frame`: The annotated FrameNet frame for this trigger
  - `frame_defintion`: The definition of the `frame` as given in the FrameNet documentation
- `report_template`: The set of arguments for the annotated trigger that have been annotated in the report. These are specified as a JSON dictionary whose keys are the roles of the trigger's `frame` and whose values are themselves JSON dictionaries with the following information pertaining to a given role:
  - `definition`: The official definition of this role as given in the FrameNet documentation
  - `arguments`: A list of spans from the `report` that refer to arguments of the trigger that satisfy this role, where each span refers to a distinct argument. Note that the list may be empty; this means that no arguments were annotated for this role.
- `summary_template`: The set of arguments for the annotated trigger that are contained in the summary you write. This will be pre-populated with the exact same arguments as are found in the `report_template`, but you will need to update the `summary_template` arguments if you paraphrase them or otherwise change them in your summaries. (More on this below.)
- `summary`: This is where you will write your summary.
- `comments`: A field for providing any additional comments or concerns about the annotation for this example.
- `cannot_annotate`: A field that should be set to `true` if and only if it is impossible to write a summary for this example. For instance, this may be the case if the annotated event has no arguments.

Next, we detail the annotation process.

## Annotation Process

### Overview

Below is a possible annotation workflow to follow for each example. You should feel free to adopt an alternative workflow if you find it works better for you (e.g., you might find you prefer doing (2) before (1) in the steps below).

1. Look at the `trigger`, and `report_template` fields to determine (a) roughly what the target event is about (b) what kind of arguments you should be looking for in the `report`. If you don't understand the meaning of the `frame` or of the roles for some of its arguments even after reading the provided definitions, you should (as mentioned above) search for the frame in the [Frame Index](https://framenet.icsi.berkeley.edu/frameIndex) and read through the definitions and examples provided there.
2. Read the `report` text, paying particular attention to the description of the annotated event.
3. Make any necessary corrections to the annotated arguments in the `report_template` based on your reading of the `report` text in (2). This may entail adding, removing, or altering the spans of the arguments.
4. Write your summary of the annotated event (taking into account any annotation corrections you have made) in the `summary` field.
5. Make any necessary changes to the arguments in the `summary_template` (e.g. if you paraphrased any arguments from the `report_template` or if you made corrections to them in step (3)).

### Detailed Annotation Instructions

The remainder of these instructions provide more detail about (1) how and when to go about correcting argument annotations, and (2) how the summaries should be written.

#### Correcting the Argument Annotations

As mentioned above, the argument annotations are given in the `report_template` dictionary. These annotations were provided by a trusted set of workers on Amazon Mechanical Turk and so should generally be correct. However, you may occasionally discover that the annotations have errors. These errors may include (1) spurious arguments, (2) missing arguments, or (3) arguments with only incorrect span boundaries. The annotations for a particular role are correct when all and only the arguments in the `report` text that satisfy that role are annotated. Here's how to ensure the annotations are correct:

- You should read the provided definition of each role in order to determine what kind of arguments need to be annotated (if present). As suggested above, you can also scan over the `trigger` and the annotated `arguments` to get a sense for what the event is about.
  - Note: each `frame` type has its own distinct set of roles, though the `Time` and `Place` roles are shared by all frames.
- Next, read the `report` text.
- Now look back at the annotated arguments to see whether they seem correct, having read the report. Spurious arguments (when they occur) should fairly immediately jump out at you as wrong, but missing arguments can be harder to spot, so pay especially careful attention to these. We expect the third type of error &mdash; incorrect span boundaries &mdash; to be the rarest.
- If you see...
  - ...A spurious argument: delete it from the `report_template` annotations (delete *just* the span)
  - ...A missing argument: add it to the `report_template` annotations. All arguments MUST BE contiguous spans in the `report` and should be added exactly as it appears in the text
  - ...An argument with incorrect span boundaries: Edit the span boundaries in the `report_template` annotations &mdash; again, ensuring that the resulting span is still a contiguous one from the `report` text

If you ever feel conflicted about whether an annotation is correct or not, please defer to the existing annotations and leave them unchanged. Once you have made these corrections, you are now ready to write the summary. More on this next.

#### Writing the Summaries

The summaries you will be writing are "event-keyed." This means they (1) are focused specifically on the annotated event and (ideally) no other; and (2) convey all of the same information as is conveyed by the annotations in the `report_template` (*after* any corrections you make to those annotations). Here are some more detailed instructions:

- Occasionally, it may be necessary or desirable to provide some minimal additional information in your summary (beyond what can be gleaned from the annotations) in order for the summary to stand by itself as a complete description of the event. This is fine, but your additions should ideally be such that your hypothetical summary reader would not be inclined to identify in your summary any novel arguments of the event not present in the annotations. Furthermore, any additional details should always be ones for which there is clear support in the text; they should *NOT* be based on external or background knowledge you happen to have.
- Summaries should express the role that each argument plays in the event in a natural, integrated way. It should NOT read as stilted and it definitely should NOT use the names of particular roles. For instance, if we were dealing with a `Commerce_sell` event, you should say (e.g.) "George sold some apples to Martha." You should NOT say (e.g.) "The seller was George. The buyer was Martha. The goods were some apples."
- You'll note that the report text is tokenized at the word level. Your summaries should follow the same tokenization scheme as closely as possible (e.g. punctuation and possessive `'s` should be offset by whitespace, etc.). This is somewhat unnatural, but it will make postprocessing the annotations easier.
- In general, you should try to write the argument spans exactly as they appear in the `report_template` annotations. Sometimes, however, it may be difficult or even impossible to write a clear and natural summary without paraphrasing a particular argument span. This is acceptable, but if you paraphrase or otherwise alter an argument span, you should edit that span in the `summary_template` annotations (*NOT* the `report_template` annotations) to match the way it appears in your summary.
- Your summaries MUST be shorter than the report text, and ideally quite a bit shorter. Often, the report text will describe more than just the event of interest. However, even in cases where it describes *only* the event of interest &mdash; cases where you may be tempted just to copy the report text directly into the `summary` field &mdash; please still try to paraphrase the report's description at least somewhat.
- In some instances, the `report` text may seem incomplete &mdash; e.g. a pronoun will be used to refer to one of the participants without any indication of who or what the referent of the pronoun is. This is unavoidable and your summaries should simply preserve any references that cannot be resolved from the `report` text alone.

**Additional Tip**: Assuming you are doing this annotation directly in the JSON files, the `report` text will be much more readable if you use an IDE (Integrated Development Environment) that supports line wrapping. If you are working in VS Code, line wrapping can be enabled/disabled with the shortcut `option+z`.

## Examples

Here, we present a couple of examples of good event-keyed summaries for reference. These examples are taken from the `dev` split. Note that we have omitted the `summary_template` for readability, as none of the arguments in these examples are edited from the way they appear in the `report_template`.

### Example 1

```json
    {
      "instance_id": "EN-4898-324-frame-Achieving_first",
	    "trigger": {
        "text": "discoverers",
        "frame": "Achieving_first",
        "frame_definition": "A Cognizer introduces a New_idea into society."
      },
      "report_template": {
        "Cognizer": {
          "definition": "The Cognizer comes up with or conceptualizes the New_idea. It is normally expressed as an External Argument:",
          "arguments": [
            "Carl Ferdinand Cori",
            "Gerty Cori"
          ]
        },
        "New_idea": {
          "definition": "The New_idea is a concept not previously present in society which the Cognizer introduces.",
          "arguments": [
            "The Cori cycle"
          ]
        },
        "Time": {
          "definition": "This role identifies the Time when the Cognizer comes up with the New_idea.",
          "arguments": []
        },
        "Place": {
          "definition": "This role identifies the Place where the Cognizer comes up with the New_idea.",
          "arguments": []
        }
      },
      "report": "right|thumb|460px| Cori cycle The Cori cycle ( also known as the lactic acid cycle ) , named after its discoverers , Carl Ferdinand Cori and Gerty Cori , is a metabolic pathway in which lactate produced by anaerobic glycolysis in muscles is transported to the liver and converted to glucose , which then returns to the muscles and is cyclically metabolized back to lactate .",
	    "summary": "The Cori cycle , a metabolic pathway that converts lactate to glucose , was discovered by Carl Ferdinand Cori and Gerty Cori ."
   }
```

**Comments**: This example does not require any annotation correction. The annotated event here has the frame type `Achieving_first`, which is used for events in which something is discovered or invented. The summary succinctly communicates what was discovered (the `New_idea`) and who discovered it (the `Cognizer`s). It adds a little bit of detail about what the Cori cycle is, since this detail is provided in the report, and would likely be helpful to a reader not well versed in biology. But note that this information does not change what a reader would likely infer the arguments to be.

### Example 2

```json
	{
	  "instance_id": "EN-1337-261-frame-Activity_pause",
	  "trigger": {
        "text": "hiatus",
        "frame": "Activity_pause",
        "frame_definition": "An Agent pauses in the course of an Activity. ''"
      },
      "report_template": {
        "Activity": {
          "definition": "This role identifies the Activity for which an Agent is pausing.",
          "arguments": [
            "Breakfast Television"
          ]
        },
        "Agent": {
          "definition": "An Agent pauses in the course of an Activity.",
          "arguments": [
            "Rogers"
          ]
        },
        "Time": {
          "definition": "This role identifies the Time at which an Agent pauses in the course of an Activity.",
          "arguments": [
            "On September 5 , 2019"
          ]
        },
        "Place": {
          "definition": "This role identifies the Place where an Agent pauses in the course of an Activity.",
          "arguments": []
        }
      },
      "report": "On September 5 , 2019 , Rogers laid off four employees from CKVU and placed Breakfast Television on hiatus until September 23 . At this time the program was relaunched with a new hybrid format , consisting of a mixture of local content with national entertainment and lifestyle segments produced from Toronto .",
	    "summary": "Rogers placed the show Breakfast Television on hiatus from September 5 , 2019 until September 23 ."
	}
```

**Comments**: This example likely also does not require any annotation correction. From the `report`, it seems like "CKVU" is probably the TV station on which "Breakfast Television" aired, and there is thus a case to be made that "CKVU" should be marked as the `Place`. However, this seems borderline, and so here we defer to the existing annotations and omit it from the summary. This report features an `Activity_pause` event &mdash; a situation in which some event or process is temporarily paused. The summary focuses *just* on the imposed hiatus (=the pause) and includes all of the annotated arguments. Note that it *excludes* any discussion about the (likely related) incident in which four employees were laid off, but *includes* an essential detail of the hiatus &mdash; its end date &mdash; which doesn't appear in the annotations (since there is no role corresponding to this information). Essential details of this sort are ones that are okay to include in the summary even if they don't appear in the annotations. Generally speaking, though, you should be fairly frugal in adding details, and these details should always be ones for which there is clear evidence in the text.

### Example 3

```json
    {
      "instance_id": "EN-4349-526-frame-Breaking_out_captive",
      "trigger": {
        "text": "freed",
        "frame": "Breaking_out_captive",
        "frame_definition": "An Agent brings about the end of a Theme's captivity at a Location_of_confinement in contravention of the plans or desires of a captor."
      },
      "report_template": {
        "Agent": {
          "definition": "The Agent is the individual who ends the confinement or captivity of the Theme.",
          "arguments": [
            "Lincoln"
          ]
        },
        "Theme": {
          "definition": "The Theme is the person or object in motion released by the Agent.",
          "arguments": [
            "the slaves"
          ]
        },
        "Location_of_confinement": {
          "definition": "The location to which the Theme's motion was formerly inhibited.",
          "arguments": [
            "the slaveholders" // this should be deleted!
          ]
        },
        "Time": {
          "definition": "The Time identifies when the Agent release the Theme .",
          "arguments": [
            "the Civil War"
          ]
        },
        "Place": {
          "definition": "The location where the Theme ceases to be confined.",
          "arguments": [
            "the southern states"
          ]
        }
      },
      "report": "These claims include that the Civil War was Abraham Lincoln 's war by choice , that slavery was dying anyway , that Lincoln could have freed the slaves by paying the slaveholders and that Lincoln armed the slaves . More specifically , in a Daily Show segment , he said that Lincoln started the war \" because he wanted to preserve the union , because he needed the tariffs from the southern states , \" a claim rejected by a panel of three distinguished historians of the Civil War : James Oakes , Eric Foner and Manisha Sinha . Napolitano argued that Lincoln could have solved the slavery question by paying slaveholders to release their slaves , a method known as compensated emancipation , thereby avoiding war .",
      "summary": "It is claimed that Lincoln could have freed the slaves in the southern states during the Civil War by paying the slaveholders ."
    },
```

**Comments**: This annotation has at least one incorrect annotation: "the slaveholders" for `Location_of_confinement`. It's probably okay to include "the southern states" as the `Place` where the slaves are freed, but it seems borderline as to whether this annotation is actually inferrable from the text (which is a requirement for these annotations), as opposed to world knowledge we bring to bear about the history of slavery in the U.S. Because this is a borderline case, we defer to the existing annotations and include this fact in our summary. We include "the slaveholders" in our summary because it is critically related to how Lincoln could have freed the slaves (according to the text), but it should still be deleted from the `Location_of_confinement` annotation above because "the slaveholders" do not satisfy this role.

## Questions

Please feel free to reach out to me directly with any questions.