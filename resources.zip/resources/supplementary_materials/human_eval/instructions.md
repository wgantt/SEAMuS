# Overview

In this task, you will be evaluating the quality of short summaries written about some situation. Each example will focus on a single situation and will feature two documents that describe that situation:

1. The `report` is a short excerpt from a Wikipedia article.
1. The `source` is a longer web article that discusses the same situation as the `report` (often among other several other topics) and that may contain additional, or somewhat different information about that situation.

The summaries you will be evaluating are supposed to synthesize details about the situation from *both* the `report` and the `source`. These details are represented using the [FrameNet](https://framenet.icsi.berkeley.edu/) ontology, a semantic formalism based on the theory of [Frame Semantics](https://en.wikipedia.org/wiki/Frame_semantics_(linguistics)). You do not need to have a thorough understanding of either FrameNet or Frame Semantics to perform this task; the information provided below and in the annotation file should be sufficient.

# Example Structure

Concretely, each example will contain the following information:

- `frame`: The type of the situation of interest in the FrameNet ontology.
- `frame_definition`: The definition of the frame as given in FrameNet.

Additional details about the situation are provided separately for the `report` and for the `source`, since the way they describe the situation of interest often differs. For the `report`, we have the following information:

- `trigger`: The word or phrase in the `report` that most clearly evokes the situation.
- `report_event`: A dictionary containing the semantic roles (called "Frame Elements" in FrameNet) associated with the `frame`, along with (a) the FrameNet `definition` of each role, and (b) a list of participants satisfying that role in the `report`.

For the `source`, we have only the following information:

- `source_event`: A dictionary exactly analogous in structure to `report_event`, but that provides information about participants in the `source`.

Finally, each example also has a list of eight summaries (`summary_1`, ..., `summary_8`) that have been written about the situation based on all the information provided above, and that you are responsible for evaluating by entering a score (1-5) in the `score` field. Next, we discuss how you should go about doing this evaluation.

# Evaluating Summaries

You are to assign an overall score to each of the eight summaries on a scale from 1 (very low quality) to 5 (very high quality); half-points (e.g. 1.5, 2.5, etc.) are permitted.

The summaries are intended to focus narrowly on the situation of interest, so your score for each should reflect how good it is *as a summary of that situation only*; the aim is *NOT* to summarize the entire report document, source document, or their combination. We recognize that providing a single overall score for summary quality can be challenging, as there are numerous dimensions on which quality can be judged. For the purposes of this task, we ask that you base your score only on the following quality dimensions, and that you prioritize them in the order in which they are given below (with 1 being highest priority).

1. **Consistency**/**Factuality**: *Does the summary make only true statements about the situation of interest, given what the `report` and the `source` say about that situation, and given the information contained in the `report_event` and `source_event` fields?*
    - Summaries that make factual errors of any kind should be penalized (proportional to the seriousness of those errors)
    - One type of factual error to pay especially careful attention to is whether the summary misrepresents the role of a particular participant included in either the `report_event` or the `source_event`. Reading the provided role `definition`s can help you determine this.
2. **Adequacy**: *Does the summary adequately capture all of the information contained in the `report_event` and the `source_event`?*
    - Summaries that omit details about any of the participants in the event should be penalized (again, proportionally).
    - **NOTE**: The `report_event` and the `source_event` often feature the same participant(s) for a given role but under different descriptions. When this happens, the summary should ideally use the more informative of the two descriptions of that participant, where proper names (e.g. *Barack Obama*) are more informative than nominal expressions (*the former President*), which in turn are more informative than pronouns (*he, him*). Summaries failing to observe this practice should be penalized. Naturally, the two descriptions may differ while being equally informative; in such cases, either description should be judged acceptable.
    - **NOTE**: The `report_event` and the `source_event` will of course also sometimes have genuinely *different* participants for a given role (e.g. the `source_event` may have an additional participant for some role that the `report_event` does not have). The summaries are expected to include *all* participants mentioned in *either* the `source_event` or the `report_event`. Summaries failing to do this should be penalized.
3. **Coherence**: *Does the summary make sense on its own, as a standalone description of the situation?*
    - Summaries that require you to go read either the `report` or the `source` in order to understand what they mean &mdash; or that don't make sense even then &mdash; should be penalized.
4. **Relevancy**: *Does the summary include only information that is relevant to the situation of interest*?
    - Summaries that include irrelevant or superfluous information, or information about some situation other than the one represented in the `report_event` or the `source_event`, should be penalized.
    - **NOTE**: Some minimal additional information not expressly captured in the `report_event` or the `source_event` may be necessary for **coherence** &mdash; i.e. for the summary to be a complete, self-contained description of the situation. You must use your own judgment to determine whether information provided in a summary serves this purpose (in which case it should *not* be penalized) or not (in which case, it should).
5. **Fluency**: *Does the summary sound reasonably natural (like something a native English speaker might actually write)?*
    - Summaries that are disfluent or that sound unnatural should be penalized.


Oftentimes, some of the summaries may be very similar to each other. It is completely fine to give multiple summaries the same score if you think they are of equal quality.

You should enter your score for each summary in the `score` field. The default value shown is 0, which is an invalid score and must be replaced by your actual score (1-5). There are 30 examples in total, and 8 summaries per example, so there will be 240 total scores to provide.

When you are done, please return the file to me, saving it as `<your_last_name>_data.json`. Feel free to contact me with any questions.