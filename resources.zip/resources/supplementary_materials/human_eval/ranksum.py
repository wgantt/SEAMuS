import click
import numpy as np
import os
import pandas as pd

from itertools import combinations
from scipy.stats import mannwhitneyu

from seamus.constants import PROJECT_ROOT

# invoke this script from the root with PYTHONPATH=.
# i.e. PYTHONPATH=. python resources/supplementary_materials/human_eval/ranksum.py
HUMAN_EVAL_RESULTS = os.path.join(
    PROJECT_ROOT,
    "resources",
    "supplementary_materials",
    "human_eval",
    "results",
    "results.csv",
)
SIGNIFICANCE_LEVEL = 0.05


@click.command()
def eval():
    data = pd.read_csv(HUMAN_EVAL_RESULTS)
    annotators = sorted(data["annotator"].unique())
    models = sorted(data["model"].unique())
    for a in annotators:
        print("-----------")
        print(f"Annotator {a}")
        print("-----------")
        for m1, m2 in combinations(models, 2):
            if m1 != m2:
                m1_obs = data[(data.annotator == a) & (data.model == m1)].sort_values(
                    by="item_id"
                )["score"]
                m2_obs = data[(data.annotator == a) & (data.model == m2)].sort_values(
                    by="item_id"
                )["score"]
                avg_diff = abs(np.mean(np.array(m1_obs) - np.array(m2_obs)))
                u1, p = mannwhitneyu(m1_obs, m2_obs, alternative="two-sided")
                u2 = len(m1_obs) * len(m2_obs) - u1
                if p < SIGNIFICANCE_LEVEL:
                    if u1 > u2:
                        print(f"{m1} (U={np.round(u1,3)})")
                        print(f"{m2} (U={np.round(u2,3)})")
                        print(
                            f"{m1} is better (p={np.round(p,3)}, avg_diff={np.round(avg_diff, 3)})"
                        )
                    else:
                        print(f"{m2} (U={np.round(u2,3)})")
                        print(f"{m1} (U={np.round(u1,3)})")
                        print(
                            f"{m2} is better (p={np.round(p,3)}, avg_diff={np.round(avg_diff, 3)})"
                        )
                    print("--------------------------------------------------")
                    print()


if __name__ == "__main__":
    eval()
