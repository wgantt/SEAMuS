# Supplementary Materials

This archive contains the supplementary materials for the paper "Cross-Document Event-Keyed Summarization". There are two subdirectories:

- `annotation/`: Files pertaining to Phase 1 and Phase 2 annotation of the SEAMuS dataset (section 3 of the paper)
- `human_eval/`: Files pertaining to the human evaluation of model outputs on SEAMuS (section 5)

Further details are provided in the README of each subdirectory.
