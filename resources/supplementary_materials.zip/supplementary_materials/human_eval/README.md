This directory contains two files and one subdirectory:
- `instructions.md`: The instructions provided to the three raters who participated in the human evaluation (section 5).
- `human_eval_items.json`: The JSON file containing the items to be rated, also as it was provided to the human raters.
- `human_eval_keys.json`: The JSON file containing the items to be rated, but with the provenance of each summary revealed.
- `ranksum.py`: Script for running paired Wilcoxon rank-sum tests of raters' judgments of summary quality.
- `results/`
    - `a1_data.json`, `a2_data.json`, `a3_data.json`: JSON files containing the responses from the three raters.
    - `results.csv`: A CSV that contains all the individual scores from `a1_data.json`, `a2_data.json`, and `a3_data.json`, along with the provenance of each summary.
